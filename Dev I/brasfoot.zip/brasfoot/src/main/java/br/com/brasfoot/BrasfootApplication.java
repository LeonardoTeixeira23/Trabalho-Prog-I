package br.com.brasfoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrasfootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrasfootApplication.class, args);
	}

}
