package br.com.brasfoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrasfootApplicationTests {

	@Test
	void contextLoads() {
	}

}
